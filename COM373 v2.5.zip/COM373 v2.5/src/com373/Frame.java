/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author B00731337
 */
public class Frame extends JFrame 
{
    JPanel cards;
    
    public Frame()
    {
       JMenuBar menu = new JMenuBar();
        
       JMenu file = new JMenu("Navigation Menu");
        
       JMenuItem exit = new JMenuItem();
       JMenuItem homePage = new JMenuItem();
       JMenuItem createCurAccount = new JMenuItem();
       JMenuItem createSavAccount = new JMenuItem();
       JMenuItem CAInterface = new JMenuItem();
       JMenuItem SAInterface = new JMenuItem();
       homePage.setText("Home Page");
       createCurAccount.setText("Create Current Account");
       createSavAccount.setText("Create Savings Account");
       CAInterface.setText("Current Account Management");
       SAInterface.setText("Current Savings Management");
       Home_Page card1 = new Home_Page();  
       Create_CA card2 = new Create_CA();
       Create_SA card3 = new Create_SA();
       CA_Interface card4 = new CA_Interface();
       SA_Interface card5 = new SA_Interface();
       cards = new JPanel(new CardLayout());
       cards.add(card1,"Card 1");
       cards.add(card2,"Card 2");
       cards.add(card3,"Card 3");
       cards.add(card4,"Card 4");
       cards.add(card5,"Card 5");
       exit.setText("Exit");
       
       homePage.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   CardLayout cardLayout = (CardLayout) cards.getLayout();
                   cardLayout.show(cards, "Card 1");
                   Frame.this.setSize(300,300);
               }
           }
       );
       createCurAccount.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   CardLayout cardLayout = (CardLayout) cards.getLayout();
                   cardLayout.show(cards, "Card 2");
                   Frame.this.setSize(450,300);
               }        
           }
       );
       createSavAccount.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   CardLayout cardLayout = (CardLayout) cards.getLayout();
                   cardLayout.show(cards, "Card 3");
                   Frame.this.setSize(450,300);
               }
           }
       );
       CAInterface.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   CardLayout cardLayout = (CardLayout) cards.getLayout();
                   cardLayout.show(cards, "Card 4");
                   Frame.this.setSize(1000,1000);
               }
           }
       );
       SAInterface.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   CardLayout cardLayout = (CardLayout) cards.getLayout();
                   cardLayout.show(cards, "Card 5");
                   Frame.this.setSize(1000,1000);
               }
           }
       );
       exit.addActionListener
       (
           new ActionListener() 
           {
               public void actionPerformed(ActionEvent e) 
               {
                   System.exit(0);
               }
           }
       );
       
       file.add(homePage);
       file.add(createCurAccount);
       file.add(createSavAccount);
       file.add(CAInterface);
       file.add(SAInterface);
       file.add(exit); 
       menu.add(file);
        
       setJMenuBar(menu);
       
       add(cards);
    }
}
