/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
/**
 *
 * @author B00731337
 */
public class Frame extends JFrame 
{
    //JPanel cards;
    private Draw_Panel drawPanel;
    private JPanel primaryPane;
    private Control_Panel contPanel;
    
    Current_Account ca = new Current_Account();
    Savings_Account sa = new Savings_Account();
    
    public Frame()
    {
       JMenuBar menu = new JMenuBar();
        
       JMenu file = new JMenu("Navigation Menu");
       
       JMenuItem exit = new JMenuItem();
       JMenuItem homePage = new JMenuItem();
       JMenuItem createCurAccount = new JMenuItem();
       JMenuItem createSavAccount = new JMenuItem();
       JMenuItem CAInterface = new JMenuItem();
       JMenuItem SAInterface = new JMenuItem();
       homePage.setText("Home Page");
       createCurAccount.setText("Create Current Account");
       createSavAccount.setText("Create Savings Account");
       CAInterface.setText("Current Account Management");
       SAInterface.setText("Current Savings Management");
//       Home_Page card1 = new Home_Page();  
//       Create_CA card2 = new Create_CA();
//       Create_SA card3 = new Create_SA();
//       CA_Interface card4 = new CA_Interface();
//       SA_Interface card5 = new SA_Interface();
//       cards = new JPanel(new CardLayout());
//       cards.add(card1,"Card 1");
//       cards.add(card2,"Card 2");
//       cards.add(card3,"Card 3");
//       cards.add(card4,"Card 4");
//       cards.add(card5,"Card 5");
       exit.setText("Exit");
       
       drawPanel = new Draw_Panel();
       drawPanel.setPreferredSize(new Dimension (300,300));
       
       homePage.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
//                   CardLayout cardLayout = (CardLayout) cards.getLayout();
//                   cardLayout.show(cards, "Card 1");
//                   Frame.this.setSize(300,300);
               }
           }
       );
       createCurAccount.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   Frame.this.displayCAMessage();
//                   CardLayout cardLayout = (CardLayout) cards.getLayout();
//                   cardLayout.show(cards, "Card 2");
//                   Frame.this.setSize(450,300);
                   
               }        
           }
       );
       createSavAccount.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   Frame.this.displaySAMessage();
//                   CardLayout cardLayout = (CardLayout) cards.getLayout();
//                   cardLayout.show(cards, "Card 3");
//                   Frame.this.setSize(450,300);
               }
           }
       );
       CAInterface.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   Frame.this.currentAccountOptions();
//                   CardLayout cardLayout = (CardLayout) cards.getLayout();
//                   cardLayout.show(cards, "Card 4");
//                   Frame.this.setSize(1000,1000);
               }
           }
       );
       SAInterface.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   Frame.this.savingsAccountOptions();
//                   CardLayout cardLayout = (CardLayout) cards.getLayout();
//                   cardLayout.show(cards, "Card 5");
//                   Frame.this.setSize(1000,1000);
               }
           }
       );
       exit.addActionListener
       (
           new ActionListener() 
           {
               public void actionPerformed(ActionEvent e) 
               {
                   System.exit(0);
               }
           }
       );
 
       contPanel = new Control_Panel(drawPanel);
       
       primaryPane = new JPanel(new BorderLayout());
       
       primaryPane.add(drawPanel, BorderLayout.NORTH);
       primaryPane.add(contPanel, BorderLayout.SOUTH);
       
       
       file.add(homePage);
       file.add(createCurAccount);
       file.add(createSavAccount);
       file.add(CAInterface);
       file.add(SAInterface);
       file.add(exit); 
       menu.add(file);
        
       setJMenuBar(menu);
       
       this.add(primaryPane);
    }
        protected void displayCAMessage()
       {
           float temp = Float.parseFloat(JOptionPane.showInputDialog("Enter Current Account balance"));
           ca.createAccount(temp);
           String otherTemp = String.valueOf(ca.getAmount());
           JOptionPane.showMessageDialog(this,"Balance = " + otherTemp , "Your Balance", JOptionPane.PLAIN_MESSAGE);
                   
       }
        protected void displaySAMessage()
       {
           float temp = Float.parseFloat(JOptionPane.showInputDialog("Enter Current Account balance"));
           sa.createAccount(temp);
           String otherTemp = String.valueOf(sa.getAmount());
           JOptionPane.showMessageDialog(this,"Balance = " + otherTemp, "Your Balance",JOptionPane.PLAIN_MESSAGE);
                   
       }
        protected void currentAccountOptions()
        {
            Object[] options = {"Deposit","Withdrawal", "Cancel"};
            int n = JOptionPane.showOptionDialog(this, "Would you like to make a deposit or a Withdrawal?", "Current Account Management", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
            
            if(n == 0)
            {
                float temp = Float.parseFloat(JOptionPane.showInputDialog("Enter Current Account balance"));
                ca.createDeposit(temp);
                String otherTemp = String.valueOf(ca.getAmount());
                JOptionPane.showMessageDialog(this,"Balance = " + otherTemp , "Your Balance", JOptionPane.PLAIN_MESSAGE);
            }
            else if(n == 1)
            {
                float temp = Float.parseFloat(JOptionPane.showInputDialog("Enter Current Account balance"));
                ca.createWithdrawal(temp);
                String otherTemp = String.valueOf(ca.getAmount());
                JOptionPane.showMessageDialog(this,"Balance = " + otherTemp , "Your Balance", JOptionPane.PLAIN_MESSAGE);
            }
            else if(n == 2)
            {
                
            }
        }
        protected void savingsAccountOptions()
        {
            Object[] options = {"Deposit","Withdrawal", "Cancel"};
            int n = JOptionPane.showOptionDialog(this, "Would you like to make a deposit or a Withdrawal?", "Savings Account Management", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
            
            if(n == 0)
            {
                float temp = Float.parseFloat(JOptionPane.showInputDialog("Enter Savings Account balance"));
                sa.createDeposit(temp);
                String otherTemp = String.valueOf(sa.getAmount());
                JOptionPane.showMessageDialog(this,"Balance = " + otherTemp , "Your Balance", JOptionPane.PLAIN_MESSAGE);
            }
            else if(n == 1)
            {
                float temp = Float.parseFloat(JOptionPane.showInputDialog("Enter Savings Account balance"));
                sa.createWithdrawal(temp);
                String otherTemp = String.valueOf(sa.getAmount());
                JOptionPane.showMessageDialog(this,"Balance = " + otherTemp , "Your Balance", JOptionPane.PLAIN_MESSAGE);
            }
            else if(n == 2)
            {
                
            }
        }
}
