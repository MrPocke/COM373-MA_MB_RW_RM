/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

/**
 *
 * @author B00731185
 */
public class Text_File 
{
    private String path;
    private boolean append_to_file = false;
    
    public Text_File(String file_path)
    {
        path = file_path;
    }
}
