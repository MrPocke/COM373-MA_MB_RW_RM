/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
/**
 *
 * @author B00731185
 */
public class Create_SA extends javax.swing.JPanel
{
    private static final int BUTTON_WIDTH = 180;
    private static final int BUTTON_HEIGHT = 30;
    private static final int LABEL_WIDTH = 120;
    private static final int LABEL_HEIGHT = 20;
    private NumberFormat amountFormat;
    
    private JLabel label;
    private JFormattedTextField amount;
    private JButton saveButton;
    
    public Create_SA()
    {
        label = new JLabel("Enter initial Balance");
        amount = new JFormattedTextField(amountFormat);
        amount.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
        saveButton = new JButton("Create Savings Account");    
        saveButton.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
        add(label);
        add(amount);
        add(saveButton); 
    }         
    private void setUpFormats()
    {
        amountFormat = NumberFormat.getCurrencyInstance();
    }
}

