/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;

import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.event.*;
/**
 *
 * @author B00731337
 */
public class Home_Page extends javax.swing.JPanel  
{
    private static final int BUTTON_WIDTH = 250;
    private static final int BUTTON_HEIGHT = 60;
    
    private JLabel welcome;
    
    Create_CA currentAccount = new Create_CA();
    public Home_Page()
    {
        this.setLayout(new BorderLayout());
        welcome = new JLabel("<html>Welcome<br/>Select a menu item from the upper left corner</html>");
        add(welcome);
    }
    JPanel panel;
}
