/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/**
 *
 * @author B00731185
 */
public class Create_CA extends javax.swing.JPanel 
{
    private static final int BUTTON_WIDTH = 180;
    private static final int BUTTON_HEIGHT = 30;
    private static final int LABEL_WIDTH = 120;
    private static final int LABEL_HEIGHT = 20;
    private NumberFormat amountFormat;
    
    private JLabel label;
    private JFormattedTextField amount;
    private JButton saveButton;
    
    public Create_CA() 
    {
        label = new JLabel("Enter initial Balance");
        amount = new JFormattedTextField(amountFormat);
        amount.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
        saveButton = new JButton("Create Current Account");    
        saveButton.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
        add(label);
        add(amount);
        add(saveButton); 
        
        saveButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                float temp = Float.parseFloat(amount.getText());
                Current_Account cur = new Current_Account();
                cur.createAccount(temp);
                amount.setValue("");
            }
        });      
    }
//    private ActionListener getButtonAction()
//    {
//        ActionListener action = new ActionListener()
//        {
//            @Override
//            public void actionPerformed(ActionEvent e)
//            {}
//        };
//        return action;
//    }
    private void setUpFormats()
    {
        amountFormat = NumberFormat.getCurrencyInstance();
    }
}
