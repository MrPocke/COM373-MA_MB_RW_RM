/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;
import javax.swing.JPanel; 
/**
 *
 * @author B00731185
 */
public class Draw_Panel extends JPanel
{
    
}
