/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
/**
 *
 * @author B00731185
 */
public class SA_Interface extends javax.swing.JPanel
{
    private static final int BUTTON_WIDTH = 180;
    private static final int BUTTON_HEIGHT = 30;
    private static final int LABEL_WIDTH = 120;
    private static final int LABEL_HEIGHT = 20;
    private NumberFormat amountFormat;
    
    private JLabel label;
    private JFormattedTextField amount;
    private JButton depositButton;
    private JButton withdrawalButton;
    
    public SA_Interface()
    {
        label = new JLabel("Savings Account Management");
        amount = new JFormattedTextField(amountFormat);
        amount.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
        depositButton = new JButton("Deposit");    
        depositButton.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
        withdrawalButton = new JButton("Withdrawal");    
        withdrawalButton.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
        
        add(label);
        add(amount);
        add(depositButton);
        add(withdrawalButton);
    }
    private void setUpFormats()
    {
        amountFormat = NumberFormat.getCurrencyInstance();
    }
}
