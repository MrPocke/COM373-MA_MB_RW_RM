/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;

import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author B00731337
 */
public class Control_Panel extends javax.swing.JPanel implements ActionListener 
{
    private static final int BUTTON_WIDTH = 250;
    private static final int BUTTON_HEIGHT = 60;
    
    private JButton cA, sA, startTimer, pauseTimer, display;
    
    Current_Account_Creation currentAccount = new Current_Account_Creation();
    public Control_Panel()
   {
       cA = new JButton("Create Current Account");
       cA.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       ButtonHandler createAccountClick = new ButtonHandler(this);
       cA.addActionListener(createAccountClick);
       add(cA);
       
       sA = new JButton("Create Savings Account");
       sA.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(sA);
       
       startTimer = new JButton("Start");
       startTimer.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(startTimer);
       
       pauseTimer = new JButton("Pause");
       pauseTimer.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(pauseTimer);
       
       display = new JButton("Display");
       display.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(display);
    }
    JPanel panel;
    
    public Control_Panel(JPanel thePanel) 
    {
        panel = thePanel;
    }
    public void actionPerformed(ActionEvent evt)
    {
        if(evt.getSource() == cA)
        {
            Current_Account_Creation currentCreation = new Current_Account_Creation();
            
        }   
    }
}
