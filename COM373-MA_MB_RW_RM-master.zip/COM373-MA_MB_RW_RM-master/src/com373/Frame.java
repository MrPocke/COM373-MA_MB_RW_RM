/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author B00731337
 */
public class Frame extends JFrame 
{
    JPanel cards;
    
    public Frame()
    {
       JMenuBar menu = new JMenuBar();
        
       JMenu file = new JMenu("Navigation Menu");
        
       JMenuItem exit = new JMenuItem();
       JMenuItem mainMenu = new JMenuItem();
       JMenuItem createCurAccount = new JMenuItem();
       JMenuItem createSavAccount = new JMenuItem();
       mainMenu.setText("Main Menu");
       createCurAccount.setText("Create Current Account");
       createSavAccount.setText("Create Savings Account");
       Control_Panel card1 = new Control_Panel();  
       Current_Account_Creation card2 = new Current_Account_Creation();
       cards = new JPanel(new CardLayout());
       cards.add(card1,"Card 1");
       cards.add(card2,"Card 2");
       exit.setText("Exit");
       
       mainMenu.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   CardLayout cardLayout = (CardLayout) cards.getLayout();
                   cardLayout.show(cards, "Card 1");
               }
           }
       );
       createCurAccount.addActionListener
       (
           new ActionListener()
           {
               public void actionPerformed(ActionEvent e)
               {
                   CardLayout cardLayout = (CardLayout) cards.getLayout();
                   cardLayout.show(cards, "Card 2");
               }        
           }
       );
       
       exit.addActionListener
       (
           new ActionListener() 
           {
               public void actionPerformed(ActionEvent e) 
               {
                   System.exit(0);
               }
           }
       );
       
       file.add(mainMenu);
       file.add(createCurAccount);
       file.add(createSavAccount);
       file.add(exit); 
       menu.add(file);
        
       setJMenuBar(menu);
       
       add(cards);
    }
}
