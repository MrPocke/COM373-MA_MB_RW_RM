/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
/**
 *
 * @author B00731337
 */
public class Frame extends JFrame 
{
    public Frame()
    {
       JMenuBar menu = new JMenuBar();
        
       JMenu file = new JMenu("File");
        
       JMenuItem exit = new JMenuItem();
       exit.setText("Exit");
       file.add(exit);
       
       menu.add(file);
        
       setJMenuBar(menu);
        
       Current_Account_Creation currentCreation = new Current_Account_Creation();
       this.add(currentCreation);
       
       Control_Panel controlPanel = new Control_Panel();
       this.add(controlPanel);    
    }
}
