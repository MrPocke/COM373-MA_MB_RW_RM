/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com373.Current_Account_Creation;
/**
 *
 * @author B00731185
 */
public class ButtonHandler implements ActionListener
{
/**
 *
 * @author B00731185
 */
    JPanel panel;
    
    public ButtonHandler(JPanel thePanel) 
    {
        panel = thePanel;
    }
    public void actionPerformed(ActionEvent evt)
    {
        
       //Current_Account_Creation currentCreation = new Current_Account_Creation();
       //Frame.add()
    }
}

