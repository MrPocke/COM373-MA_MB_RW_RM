package com373;

import javax.swing.JLabel;
import javax.swing.JButton;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B00731337
 */
public class Display_Panel extends javax.swing.JPanel
{
    private static final int BUTTON_WIDTH = 250;
    private static final int BUTTON_HEIGHT = 60;
    
    private JButton CAMax, CAMin, SAMax, SAMin;
    
    public Display_Panel()
   {
       CAMax = new JButton("Create Current Account");
       CAMax.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(CAMax);
       
       SAMax = new JButton("Create Savings Account");
       SAMax.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(SAMax);
       
       SAMin = new JButton("Start");
       SAMin.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(SAMin);
       
       CAMin = new JButton("Pause");
       CAMin.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);
       
       add(CAMin);
    }
}
