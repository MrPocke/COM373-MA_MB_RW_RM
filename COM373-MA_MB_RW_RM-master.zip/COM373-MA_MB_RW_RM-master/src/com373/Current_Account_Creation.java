/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com373;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author B00731185
 */
public class Current_Account_Creation extends javax.swing.JPanel 
{
    private static final int BUTTON_WIDTH = 250;
    private static final int BUTTON_HEIGHT = 60;
    
    public JButton saveButton;
    
    public Current_Account_Creation()
    {
        saveButton = new JButton("Save");    
        saveButton.setSize(BUTTON_WIDTH, BUTTON_HEIGHT);  
        add(saveButton);
            
    }
}
